// FFF header � Drugwash 2012
#if !defined(AFX_STDAFX_H__C8A66320_404F_4B27_AD88_1E016A4443E4__INCLUDED_)
#define AFX_STDAFX_H__C8A66320_404F_4B27_AD88_1E016A4443E4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <windows.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <tchar.h>
#include <wchar.h>
#include <strsafe.h>
#include <winerror.h>

#endif // !defined(AFX_STDAFX_H__C8A66320_404F_4B27_AD88_1E016A4443E4__INCLUDED_)
