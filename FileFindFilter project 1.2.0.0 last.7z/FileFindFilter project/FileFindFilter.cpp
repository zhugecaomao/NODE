#define _WIN32_WINNT 0x0400
#define NOMINMAX
#define STRICT
#include "stdafx.h"

typedef int (*FFFCBK) (LPVOID, LPVOID, LPTSTR, LPTSTR, LPTSTR);	// external callback should obey this definition
#define BUFSZ MAX_PATH
#define BUFSZW 0x10000	// #define BUFSZW MAX_PATH
#define BUFMAX 0x1400000	//#define BUFMAX STRSAFE_MAX_CCH *sizeof(TCHAR)
#define EXTSZ _MAX_EXT

WIN32_FIND_DATA FFFD;
HINSTANCE g_hInstance;
HANDLE hFF = INVALID_HANDLE_VALUE;
LPTSTR CurDir;	// current directory name
LPTSTR CurName;	// current file name
LPTSTR CurExt;	// current file extension
LPTSTR fext;	// clean file extension
LPTSTR tExt;	// temporary file extension
LPTSTR extC;	// extension list copy (formatted)
LPTSTR tDirStr;		// temporary directory string
LPTSTR newdirs;		// temporary recursed directory string
LPTSTR cmpStr;		// temporary comparison string
LPTSTR dirLoop;		// temporary recursed directory list string
LPTSTR RecDirs;		// final recursed directory list string
LPTSTR tmpl;
LPTSTR fname;	// filename
LPTSTR sname;	// short filename
LPTSTR at;	// output attributes string
TCHAR* atStr =  _T("RHSUDAV-TFPCONE");	// attributes reference string
TCHAR* sep = _T("|");	// separator string
size_t tmplsz;
size_t tds;		// temp dir size
size_t ods;		// old dir size
int err;		// error code
unsigned long attr;	// file attributes
int count = 0;	// keep count of the found items
int  k;
BOOL dirfound = FALSE;	// found subdir switch
BOOL cf = FALSE;	// currently found subdirs switch
#ifdef _DEBUG
TCHAR i[65];	// buffer for count converted to string (for debug purposes)
TCHAR* dbg0 = _T("\n");
TCHAR* dbg1 = _T("\nCurDir=");
TCHAR* dbg2 = _T("added=");
TCHAR* dbg3 = _T("added in 'while'=");
TCHAR* dbg4 = _T("\nNEXT PASS:\n");
TCHAR* dbg5 = _T("Directory list (dirLoop)=");
TCHAR* dbg6 = _T("\n\nFindNextFile error:\n");
TCHAR* dbg7 = _T("\n\nCount=");
FILE* hFile;
#endif
//##############################################################
BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
if (dwReason == DLL_PROCESS_ATTACH)
	g_hInstance = (HINSTANCE) hInstance;
return TRUE;
}
//##############################################################
int WINAPI FileFindFilter(_TCHAR* dirs, _TCHAR* ext, _TCHAR* name, BOOL rec, FFFCBK cbk)
//extern "C" FFF_API FileFindFilter(LPTSTR dirs, LPTSTR ext, LPTSTR name, BOOL rec, FFFCBK cbk)
{
hFF = INVALID_HANDLE_VALUE;
dirfound = FALSE;
count = 0;
(cbk) (FALSE, FALSE, NULL, NULL, NULL);	// send initialization command to callback function
StringCbLength(ext, EXTSZ, &tds);
tds += 3*sizeof(TCHAR);
extC = (LPTSTR) malloc(tds);
StringCbCopy(extC, tds, _T("|"));
StringCbCat(extC, tds, _tcslwr(ext));	// make extension list lowercase to avoid later case incompatibilities
StringCbCat(extC, tds, _T("|"));
CurName = (LPTSTR) malloc(BUFSZ);	// allocate buffer for current file name (we ASSUME filename won't be longer than MAX_PATH-2)
StringCbCopyEx(CurName, BUFSZ, name, NULL, NULL, STRSAFE_IGNORE_NULLS); // StringCbCopy doesn't fancy NULL strings :(
if ((unsigned int) (_tcschr(CurName, atoi("*"))-CurName) != _tcslen(CurName)) // append an asterisk to allow searching for anything that begins with 'name'
	StringCbCat(CurName, BUFSZ, _T("*"));	// but only if 'name' doesn't already end with an asterisk (might be buggy!)
dirLoop = (LPTSTR) malloc(BUFMAX);
StringCbCopy(dirLoop, BUFMAX, dirs);
CurDir = (LPTSTR) malloc(BUFSZW);	// initialize buffer
if (rec == FALSE)	// check if recursion is enabled and if so, loop through dirs and add subdirs to the list
	goto norec;
RecDirs = (LPTSTR) malloc(BUFMAX);	// arbitrarily allocate a buffer large enough to hold original string and recursed dirs
StringCbCopy(RecDirs, BUFMAX, dirs);	// copy original string
StringCbCat(RecDirs, BUFMAX, _T("|")); 
newdirs = (LPTSTR) malloc(BUFMAX);	// initialize newdirs
cmpStr = (LPTSTR) malloc(BUFSZW);	// initialize comparison string
#ifdef _DEBUG
hFile = _tfopen(_T("DEBUG-Folder list.txt"), _T("w+b"));
#ifdef _UNICODE
fwrite("\xFF\xFE", 1, 2, hFile);
#endif	// _UNICODE
#endif	// _DEBUG

recurse:
dirfound = FALSE;
StringCbCopy(newdirs, BUFMAX, _T(""));
tDirStr = _tcstok(dirLoop, sep);	// use _tcstok to break dirs list into paths, then find subdirs
while (tDirStr != NULL)
	{
	cf = FALSE;
	//StringCbCopy(CurDir, BUFSZW, _T("\\\\?\\"));
	//StringCbCat(CurDir, BUFSZW, tDirStr);
	StringCbCopy(CurDir, BUFSZW, tDirStr);
	StringCbCat(CurDir, BUFSZW, _T("\\*"));	// append a backslash and asterisk meaning 'search all names'
	hFF = FindFirstFile(CurDir, &FFFD);
	if (hFF == INVALID_HANDLE_VALUE || tDirStr == _T("\n"))
		goto nextdirtoken;
	if ((FFFD.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{
#ifdef _DEBUG
		fwrite(dbg1, sizeof(TCHAR), _tcslen(dbg1), hFile);
		fwrite(tDirStr, sizeof(TCHAR), _tcslen(tDirStr), hFile);
		fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
#endif
		StringCbCopy(cmpStr, BUFSZW, tDirStr);
		StringCbCat(cmpStr, BUFSZW, _T("\\"));
		StringCbCat(cmpStr, BUFSZW, FFFD.cFileName);
		StringCbCat(cmpStr, BUFSZW, _T("|"));
		if (_tcsicmp(FFFD.cFileName, _T(".")) != 0 && _tcsicmp(FFFD.cFileName, TEXT("..")) != 0)
			{
			StringCbCat(newdirs, BUFMAX, cmpStr);
#ifdef _DEBUG
			fwrite(dbg2, sizeof(TCHAR), _tcslen(dbg2), hFile);
			fwrite(cmpStr, sizeof(TCHAR), _tcslen(cmpStr), hFile);
			fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
#endif
			}
		}
	while (FindNextFile(hFF, &FFFD) != 0)
		{
		if ((FFFD.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
			if (_tcsicmp(FFFD.cFileName, _T(".")) != 0 && _tcsicmp(FFFD.cFileName, _T("..")) != 0)
				{
				StringCbCopy(cmpStr, BUFSZW, tDirStr);
				StringCbCat(cmpStr, BUFSZW, _T("\\"));
				StringCbCat(cmpStr, BUFSZW, FFFD.cFileName);
				StringCbCat(cmpStr, BUFSZW, _T("|"));
				if (_tcsstr(newdirs, cmpStr) == NULL && _tcsstr(RecDirs, cmpStr) == NULL)
					{
					StringCbCat(newdirs, BUFMAX, cmpStr);
					dirfound = TRUE;
					cf = TRUE;
#ifdef _DEBUG
					fwrite(dbg3, sizeof(TCHAR), _tcslen(dbg3), hFile);
					fwrite(cmpStr, sizeof(TCHAR), _tcslen(cmpStr), hFile);
					fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
#endif
					}
				}
		}
	FindClose(hFF);

	nextdirtoken:
	tDirStr = _tcstok(NULL, sep);
	}
if (dirfound == TRUE)
	{
	StringCbCat(RecDirs, BUFMAX, newdirs);
	StringCbCopyN(dirLoop, BUFMAX, newdirs, (_tcslen(newdirs)-1)*sizeof(TCHAR));	// we need to strip last colon here
#ifdef _DEBUG
	fwrite(dbg4, sizeof(TCHAR), _tcslen(dbg4), hFile);
#endif
	goto recurse;
	}
#ifdef _DEBUG
fwrite(dbg5, sizeof(TCHAR), _tcslen(dbg5), hFile);
fwrite(RecDirs, sizeof(TCHAR), _tcslen(RecDirs), hFile);
fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
fclose(hFile);
#endif
StringCbCopyN(dirLoop, BUFMAX, RecDirs, (_tcslen(RecDirs)-1)*sizeof(TCHAR));	// we need to strip last colon here
free(newdirs);
free(cmpStr);
free(RecDirs);

norec:
#ifdef _DEBUG
hFile = _tfopen(_T("DEBUG-File list.txt"), _T("w+b"));
#ifdef _UNICODE
fwrite("\xFF\xFE", 1, 2, hFile);
#endif	// _UNICODE
fwrite(dbg5, sizeof(TCHAR), _tcslen(dbg5), hFile);
fwrite(dirLoop, sizeof(TCHAR), _tcslen(dirLoop), hFile);
fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
#endif	// _DEBUG
tmpl = (LPTSTR) malloc(BUFSZW);
fname = (LPTSTR) malloc(BUFSZ);
sname = (LPTSTR) malloc(BUFSZ);
CurExt = (LPTSTR) malloc(EXTSZ);
tExt = (LPTSTR) malloc(EXTSZ);
fext = (LPTSTR) malloc(EXTSZ);
at = (LPTSTR) malloc(16*sizeof(TCHAR));
tDirStr = _tcstok(dirLoop, sep);	// Loop through directory name list and pick one at a time
while (tDirStr != NULL)
	{
	//StringCbCopy(CurDir, BUFSZW, _T("\\\\?\\UNC\\"));
	//StringCbCat(CurDir, BUFSZW, tDirStr);	// append current item from the dir list
	StringCbCopy(CurDir, BUFSZW, tDirStr);	// copy current item from the dir list
	StringCbCat(CurDir, BUFSZW, _T("\\"));	// append a backslash
	StringCbCat(CurDir, BUFSZW, CurName);	// append filename with trailing asterisk
#ifdef _DEBUG
	fwrite(dbg1, sizeof(TCHAR), _tcslen(dbg1), hFile);
	fwrite(CurDir, sizeof(TCHAR), _tcslen(CurDir), hFile);
	fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
#endif
	hFF = FindFirstFile(CurDir, &FFFD);	// Now we actually start the search for files
	if (hFF == INVALID_HANDLE_VALUE)
		goto nexttoken;
	attr = FFFD.dwFileAttributes;
	if ((attr & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)
		{
		StringCbCopy(tmpl, BUFSZW, tDirStr);
		StringCbCopy(tExt, EXTSZ, _T(" "));	//clear file extension from previous call in case we have null extension
		StringCbCopy(fext, EXTSZ, _T(""));	//clear file extension from previous call in case we have null extension
		StringCbCat(tmpl, BUFSZW, _T("\\"));
		StringCbCat(tmpl, BUFSZW, FFFD.cFileName);
		_tsplitpath(tmpl, NULL, NULL, NULL, tExt);
		StringCbCopy(fext, EXTSZ, _tcsinc(tExt));
		StringCbCopy(CurExt, EXTSZ, _T("|"));
// here we should consider any wildcard in extension list, but that might impact on speed
// so for now we just check for exact match or any match
		StringCbCat(CurExt, EXTSZ, _tcslwr(fext));	// make current extension lowercase because _tcsstr() is case-sensitive
		StringCbCat(CurExt, EXTSZ, _T("|"));
		if (_tcsstr(extC, CurExt) != NULL || _tcsstr(extC, _T("|*|")) != NULL)	// compare extension with the 'ext' list
			{
			StringCbCopy(fname, BUFSZ, FFFD.cFileName);
			StringCbCopy(sname, BUFSZ, FFFD.cAlternateFileName);
			StringCbCopy(at, 16*sizeof(TCHAR), _T(""));
			for (k = 0; k < 15; k++)
				StringCbCatN(at, 16*sizeof(TCHAR), attr & (unsigned long) pow(2, k) ? atStr+k : _T("-"), sizeof(TCHAR));
			(cbk) (tDirStr, fname, fext, sname, at);	// call the callback and pass filename and other attributes
#ifdef _DEBUG
			StringCbCopy(tmpl, BUFSZW, _T("Long path="));
			StringCbCat(tmpl, BUFSZW, tDirStr);
			StringCbCat(tmpl, BUFSZW, _T("\\"));
			StringCbCat(tmpl, BUFSZW, FFFD.cFileName);
			StringCbCat(tmpl, BUFSZW, _T("\nShort name="));
			StringCbCat(tmpl, BUFSZW, FFFD.cAlternateFileName);
			StringCbCat(tmpl, BUFSZW, _T("\nAttributes="));
			StringCbCat(tmpl, BUFSZW, at);
			StringCbCat(tmpl, BUFSZW, _T("\nExtension="));
			StringCbCat(tmpl, BUFSZW, CurExt);
			StringCbCat(tmpl, BUFSZW, _T(" - "));
			StringCbCat(tmpl, BUFSZW, tExt);
			StringCbLength(tmpl, BUFSZW, &tmplsz);
			fwrite(tmpl, sizeof(TCHAR), _tcslen(tmpl), hFile);
			fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
#endif
			count++;
			}
		}
	while (FindNextFile(hFF, &FFFD) != 0)
		{
		attr = FFFD.dwFileAttributes;
		if ((attr & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
			continue;
		StringCbCopy(tmpl, BUFSZW, tDirStr);
		StringCbCopy(tExt, EXTSZ, _T(" "));	//clear file extension from previous call in case we have null extension
		StringCbCopy(fext, EXTSZ, _T(""));	//clear file extension from previous call in case we have null extension
		StringCbCat(tmpl, BUFSZW, _T("\\"));
		StringCbCat(tmpl, BUFSZW, FFFD.cFileName);
		_tsplitpath(tmpl, NULL, NULL, NULL, tExt);
		StringCbCopy(fext, EXTSZ, _tcsinc(tExt));
		StringCbCopy(CurExt, EXTSZ, _T("|"));
		StringCbCat(CurExt, EXTSZ, _tcslwr(fext));
		StringCbCat(CurExt, EXTSZ, _T("|"));
		if (_tcsstr(extC, CurExt) == NULL && _tcsstr(extC, _T("|*|")) == NULL)	// compare extension with the 'ext' list
			continue;
		StringCbCopy(fname, BUFSZ, FFFD.cFileName);
		StringCbCopy(sname, BUFSZ, FFFD.cAlternateFileName);
		StringCbCopy(at, 16*sizeof(TCHAR), _T(""));
		for (k = 0; k < 15; k++)
			StringCbCatN(at, 16*sizeof(TCHAR), attr & (unsigned long) pow(2, k) ? atStr+k : _T("-"), sizeof(TCHAR));
		(cbk) (tDirStr, fname, fext, sname, at);	// call the callback and pass filename and other attributes
#ifdef _DEBUG
		StringCbCopy(tmpl, BUFSZW, _T("Long path="));
		StringCbCat(tmpl, BUFSZW, tDirStr);
		StringCbCat(tmpl, BUFSZW, _T("\\"));
		StringCbCat(tmpl, BUFSZW, FFFD.cFileName);
		StringCbCat(tmpl, BUFSZW, _T("\nShort name="));
		StringCbCat(tmpl, BUFSZW, FFFD.cAlternateFileName);
		StringCbCat(tmpl, BUFSZW, _T("\nAttributes="));
		StringCbCat(tmpl, BUFSZW, at);
		StringCbCat(tmpl, BUFSZW, _T("\nExtension="));
		StringCbCat(tmpl, BUFSZW, CurExt);
		StringCbCat(tmpl, BUFSZW, _T(" - "));
		StringCbCat(tmpl, BUFSZW, tExt);
		StringCbLength(tmpl, BUFSZW, &tmplsz);
		fwrite(tmpl, sizeof(TCHAR), _tcslen(tmpl), hFile);
		fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
#endif
		count++;
		}
	err = GetLastError();
	FindClose(hFF);
#ifdef _DEBUG
	if (err != ERROR_NO_MORE_FILES) 
		{
		fwrite(dbg6, sizeof(TCHAR), _tcslen(dbg6), hFile);
		fwrite((LPTSTR) _tcserror(err), sizeof(TCHAR), _tcslen((LPTSTR) _tcserror(err)), hFile);
		}
#endif
	nexttoken:
	tDirStr = _tcstok(NULL, sep);
	}
#ifdef _DEBUG
_itot(count, i, 10);
fwrite(dbg7, sizeof(TCHAR), _tcslen(dbg7), hFile);
fwrite(i, sizeof(TCHAR), _tcslen(i), hFile);
fwrite(dbg0, sizeof(TCHAR), _tcslen(dbg0), hFile);
fclose(hFile);
#endif
free(tmpl);
free(fname);
free(sname);
free(CurExt);
free(fext);
free(tExt);
free(extC);	// init
free(CurName);	//init
free(CurDir);	//init
free(dirLoop);	//init
(cbk) (FALSE, g_hInstance, NULL, NULL, NULL);	// send end of session command to callback function
return count;
}
